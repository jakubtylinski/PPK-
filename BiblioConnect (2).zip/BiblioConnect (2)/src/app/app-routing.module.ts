import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LoanBooksComponent } from './loan-books/loan-books.component';
import { BookListComponent } from './book-list/book-list.component';
import { PaymentListComponent } from './payment-list/payment-list.component';
import { LoginComponent } from './login/login.component';

const routes: Routes = [
  { path: 'loan-books', component: LoanBooksComponent },
  { path: 'book-list', component: BookListComponent },
  { path: 'payment-list', component: PaymentListComponent },
  { path: 'login', component: LoginComponent },
  { path: '', redirectTo: '/book-list', pathMatch: 'full' },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
})
export class AppRoutingModule {}