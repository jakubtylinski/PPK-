import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, of, BehaviorSubject } from 'rxjs';
import { catchError, map } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class AuthenticationService {
  private apiUrl = 'https://localhost:7172';

  private currentClientIdSubject = new BehaviorSubject<number>(0);
  currentClientId$ = this.currentClientIdSubject.asObservable();

  get currentClientId(): number {
    return this.currentClientIdSubject.value;
  }

  constructor(private http: HttpClient) {}

  login(username: string, password: string): Observable<number | null> {
    const authEndpoint = `${this.apiUrl}/user/authenticate/${username}/${password}`;

    return this.http.post<number>(authEndpoint, null)
      .pipe(
        map((clientId: number) => {
          this.currentClientIdSubject.next(clientId);
          return clientId;
        }),
        catchError((error) => {
          console.error('Authentication failed', error);
          this.currentClientIdSubject.next(0);
          return of(0);
        })
      );
  }

  logout(): void {
    this.currentClientIdSubject.next(0);
  }
}
