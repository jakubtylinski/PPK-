import { Component } from '@angular/core';
import { AuthenticationService } from '../services/authenticationService';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'],
})
export class LoginComponent {
  errorMessage = '';

  constructor(
    private authService: AuthenticationService,
    private router: Router
  ) {}

  login(
    usernameInput: HTMLInputElement,
    passwordInput: HTMLInputElement
  ): void {
    const username = usernameInput.value;
    const password = passwordInput.value;
    this.authService.login(username, password).subscribe(
      (user: any) => {
        if (user !== 0) {
          this.errorMessage = '';
          this.router.navigate(['/book-list']);
        } else {
          this.errorMessage = 'Niepoprawny login lub hasło';
        }
        console.log(user);
      },
      (error: any) => {
        console.log(error);
      }
    );
  }
}
