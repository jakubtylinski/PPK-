import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { AuthenticationService } from '../services/authenticationService';

@Component({
  selector: 'app-loan-books',
  templateUrl: './loan-books.component.html',
  styleUrls: ['./loan-books.component.css'],
})
export class LoanBooksComponent implements OnInit {
  loanedBooks: any[] = [];
  clientId: number = 0; 

  constructor(private httpClient: HttpClient, private authService: AuthenticationService) {}

  ngOnInit(): void {
    this.fetchLoanedBooks();
  }

  fetchLoanedBooks(): void {
    if (this.authService.currentClientId) {
      this.clientId = this.authService.currentClientId;
      
      this.httpClient.get<any[]>(`https://localhost:7172/bookloan/getForClient/${this.clientId}`).subscribe(
        (data) => {
          this.loanedBooks = data;
        },
        (error) => {
          console.error('Error fetching loaned books:', error);
        }
      );
    }
  }

  returnBook(bookLoanId: number): void {
    this.httpClient.put(`https://localhost:7172/bookloan/returnBook/${bookLoanId}`, {}).subscribe(
      () => {
        this.fetchLoanedBooks();
      },
      (error) => {
        console.error('Error returning book:', error);
      }
    );
  }
}