import { Component, OnInit } from '@angular/core';
import { AuthenticationService } from './services/authenticationService';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  title = 'biblio-connect';
  isLoggedIn: boolean = false;

  constructor(private authService: AuthenticationService) {}

  ngOnInit() {
    this.authService.currentClientId$.subscribe((clientId) => {
      this.isLoggedIn = clientId > 0;
    });
  }

  logout() {
    this.authService.logout();
  }
}
