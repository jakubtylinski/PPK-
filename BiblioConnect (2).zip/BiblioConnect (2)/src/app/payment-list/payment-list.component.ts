// payment-list.component.ts

import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { AuthenticationService } from '../services/authenticationService';

@Component({
  selector: 'app-payment-list',
  templateUrl: './payment-list.component.html',
  styleUrls: ['./payment-list.component.css'],
})
export class PaymentListComponent implements OnInit {
  payments: any[] = [];
  clientId?: number = 0;

  constructor(private httpClient: HttpClient, private authService: AuthenticationService) {}

  ngOnInit() {
    if (this.authService.currentClientId) {
      this.clientId = this.authService.currentClientId;

      this.httpClient
        .get<any[]>(`https://localhost:7172/payment/getPayments/${this.clientId}`)
        .subscribe(
          (data) => {
            this.payments = data;
          },
          (error) => {
            console.error('Error fetching payments:', error);
          }
        );
    }
  }
}
