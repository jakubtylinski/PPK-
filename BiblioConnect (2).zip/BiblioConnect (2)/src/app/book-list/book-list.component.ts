import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { AuthenticationService } from '../services/authenticationService';

@Component({
  selector: 'app-book-list',
  templateUrl: './book-list.component.html',
  styleUrls: ['./book-list.component.css']
})
export class BookListComponent implements OnInit {
  books: any[] = [];
  clientId: number = 0; 

  constructor(private httpClient: HttpClient, private authService: AuthenticationService) { }

  ngOnInit(): void {
    this.fetchBooks();
  }

  fetchBooks() {
    this.httpClient.get<any[]>('https://localhost:7172/book/getBooks')
      .subscribe((result) => {
        this.books = result;
      });
  }

  loanBook(bookId: number): void {
    if (this.authService.currentClientId) {
      this.clientId = this.authService.currentClientId;
      this.httpClient.post(`https://localhost:7172/bookloan/loanBook/${bookId}/${this.clientId}`, {}).subscribe(
        () => {
          this.fetchBooks();
        },
        (error) => {
          console.error('Error loaning book:', error);
        }
      );
    }
    
  }
}