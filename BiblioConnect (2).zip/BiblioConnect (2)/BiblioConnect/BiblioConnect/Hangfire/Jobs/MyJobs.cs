﻿using BiblioConnect.Services;
using Hangfire;

namespace BiblioConnect.Hangfire.Jobs
{
    public class MyJobs
    {
        private readonly EmailService _emailService;

        public MyJobs(EmailService emailService)
        {
            _emailService = emailService;
        }

        public async Task ReminderEmail()
        {
            await _emailService.SendReminder3DaysEmails();
        }
    }

}
