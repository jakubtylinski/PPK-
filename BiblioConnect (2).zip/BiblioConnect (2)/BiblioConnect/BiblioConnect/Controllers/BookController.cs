
using BiblioConnect.Services;
using Microsoft.AspNetCore.Mvc;

namespace BiblioConnect.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class BookController : ControllerBase
    {
        private readonly BookService _bookService;
        public BookController(BookService bookService)
        {
            _bookService = bookService;
        }

        [HttpGet("getBooks")]
        public IActionResult GetBooks()
        {
            var result = _bookService.GetBooks();
            return Ok(result);
        }

    }
}
