
using BiblioConnect.Services;
using Microsoft.AspNetCore.Mvc;

namespace BiblioConnect.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class PaymentController : ControllerBase
    {
        private readonly PaymentService _paymentService;
        public PaymentController(PaymentService paymentService)
        {
            _paymentService = paymentService;
        }

        [HttpGet("getPayments/{userId}")]
        public IActionResult GetPayments(int userId)
        {
            var result = _paymentService.GetForUser(userId);
            return Ok(result);
        }
    }
}
