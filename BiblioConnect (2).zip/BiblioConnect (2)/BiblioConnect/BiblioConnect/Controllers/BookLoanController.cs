using BiblioConnect.Services;
using EdiFabric.Core.Model.Edi.Edifact;
using EdiFabric.Templates.EdifactD96A;
using Microsoft.AspNetCore.Mvc;

namespace BiblioConnect.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class BookLoanController : ControllerBase
    {
        private readonly BookLoanService _bookLoanService;
        public BookLoanController(BookLoanService bookLoanService)
        {
            _bookLoanService = bookLoanService;
        }

        [HttpGet("getForClient/{clientId}")]
        public IActionResult GetForClient(int clientId)
        {
            var result = _bookLoanService.GetForClient(clientId);
            return Ok(result);
        }


        [HttpPost("loanBook/{bookId}/{clientId}")]
        public IActionResult LoanBook(int bookId, int clientId)
        {
            var ordersMessage = new TSORDERS();

            ordersMessage.UNH = new UNH();
            ordersMessage.UNH.MessageReferenceNumber_01 = "1";
            ordersMessage.UNH.MessageIdentifier_02 = new S009();
            ordersMessage.UNH.MessageIdentifier_02.MessageType_01 = "ORDER";
            ordersMessage.UNH.MessageIdentifier_02.MessageVersionNumber_02 = "D";
            ordersMessage.UNH.MessageIdentifier_02.MessageReleaseNumber_03 = "96A";

            Loop_NAD_ORDERS loop_NAD_ORDERS = new Loop_NAD_ORDERS();
            loop_NAD_ORDERS.Id = clientId;
            ordersMessage.NADLoop = new List<Loop_NAD_ORDERS>() { loop_NAD_ORDERS };

            Loop_LIN_ORDERS loop_LIN_ORDERS = new Loop_LIN_ORDERS();
            loop_LIN_ORDERS.Id = bookId;
            ordersMessage.LINLoop = new List<Loop_LIN_ORDERS>() { loop_LIN_ORDERS };
            _bookLoanService.Insert(ordersMessage);
            return Ok();
        }

        [HttpPut("returnBook/{bookLoanId}")]
        public async Task<IActionResult> ReturnBook(int bookLoanId)
        {
            var ordersMessage = new TSORDERS();

            ordersMessage.UNH = new UNH();
            ordersMessage.UNH.MessageReferenceNumber_01 = "2";
            ordersMessage.UNH.MessageIdentifier_02 = new S009();
            ordersMessage.UNH.MessageIdentifier_02.MessageType_01 = "RETURN";
            ordersMessage.UNH.MessageIdentifier_02.MessageVersionNumber_02 = "E";
            ordersMessage.UNH.MessageIdentifier_02.MessageReleaseNumber_03 = "55A";

            Loop_APR_ORDERS loop_APR_ORDERS = new Loop_APR_ORDERS();
            loop_APR_ORDERS.Id = bookLoanId;
            ordersMessage.APRLoop = new List<Loop_APR_ORDERS>() { loop_APR_ORDERS };

            await _bookLoanService.ReturnBook(ordersMessage);
            return Ok();
        }
    }
}
