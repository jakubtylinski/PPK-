
using BiblioConnect.Services;
using Microsoft.AspNetCore.Mvc;

namespace BiblioConnect.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class UserController : ControllerBase
    {
        private readonly UserService _userService;
        public UserController(UserService userService)
        {
            _userService = userService;
        }

        [HttpPost("authenticate/{username}/{password}")]
        public IActionResult Authenticate(string username, string password)
        {
            var result = _userService.Authenticate(username, password);
            return Ok(result);
        }

    }
}
