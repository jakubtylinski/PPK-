﻿namespace BiblioConnect.DbContext;

using BiblioConnect.Models.Entities;
using Microsoft.EntityFrameworkCore;

public class BiblioConnectDbContext : DbContext
{
    public DbSet<Book> Books { get; set; }
    public DbSet<Client> Clients { get; set; }
    public DbSet<BookLoan> BookLoans { get; set; }
    public DbSet<Payment> Payments { get; set; }
    public DbSet<User> Users { get; set; }

    public BiblioConnectDbContext(DbContextOptions<BiblioConnectDbContext> options) : base(options)
    {
    }
}

