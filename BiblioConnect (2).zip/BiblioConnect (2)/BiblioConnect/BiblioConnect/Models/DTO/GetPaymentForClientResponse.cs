﻿namespace BiblioConnect.Models.Entities;

public class GetPaymentForClientResponse
{
    public int PaymentID { get; set; }
    public string Title { get; set; }
    public string Author { get; set; }
    public DateTime DueToDate { get; set; }

    public decimal Amount { get; set; }
    public bool Paid { get; set; }
}