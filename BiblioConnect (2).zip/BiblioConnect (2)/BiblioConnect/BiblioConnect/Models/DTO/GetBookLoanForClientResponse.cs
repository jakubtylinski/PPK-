﻿namespace BiblioConnect.Models.Entities;

public class GetBookLoanForClientResponse
{
    public int LoanID { get; set; }
    public string Title { get; set; }
    public string Author { get; set; }
    public DateTime LoanDate { get; set; }
    public DateTime ReturnDate { get; set; }
    public bool Returned { get; set; }
}