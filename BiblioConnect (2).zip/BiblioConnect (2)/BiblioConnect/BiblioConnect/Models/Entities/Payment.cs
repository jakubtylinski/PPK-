﻿using System.ComponentModel.DataAnnotations;

namespace BiblioConnect.Models.Entities
{
    public class Payment
    {
        [Key]
        public int PaymentID { get; set; }
        public int LoanID { get; set; }
        public int ClientID { get; set; }

        public decimal Amount { get; set; }

        public bool Paid { get; set; }
        public DateTime DueToDate { get; set; }
    }
}
