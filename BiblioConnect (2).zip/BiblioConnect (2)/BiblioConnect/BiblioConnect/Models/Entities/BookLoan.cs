﻿using System.ComponentModel.DataAnnotations;

namespace BiblioConnect.Models.Entities;

public class BookLoan
{
    [Key]
    public int LoanID { get; set; }
    public int BookID { get; set; }
    public int ClientID { get; set; }
    public DateTime LoanDate { get; set; }
    public DateTime ReturnDate { get; set; }
    public bool Returned { get; set; }
}