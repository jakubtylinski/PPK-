﻿namespace BiblioConnect.Services;

using BiblioConnect.DbContext;
using BiblioConnect.Models.Entities;

public class UserService
{
    private readonly BiblioConnectDbContext _dbContext;

    public UserService(BiblioConnectDbContext dbContext)
    {
        _dbContext = dbContext;
    }

    public int Authenticate(string username, string password)
    {
        var user = _dbContext.Users.FirstOrDefault(x => x.Username == username && x.Password == password);
        if(user != null)
        {
            var client = _dbContext.Clients.FirstOrDefault(x => x.Email == user.Email);
            if(client != null)
            {
                return client.ClientID;
            }
        }
        return 0;
    }
}