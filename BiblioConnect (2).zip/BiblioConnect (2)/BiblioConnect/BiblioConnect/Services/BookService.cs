﻿namespace BiblioConnect.Services;

using BiblioConnect.DbContext;
using BiblioConnect.Models.Entities;

public class BookService
{
    private readonly BiblioConnectDbContext _dbContext;

    public BookService(BiblioConnectDbContext dbContext)
    {
        _dbContext = dbContext;
    }

    public List<Book> GetBooks()
    {
        return _dbContext.Books.ToList();
    }
}