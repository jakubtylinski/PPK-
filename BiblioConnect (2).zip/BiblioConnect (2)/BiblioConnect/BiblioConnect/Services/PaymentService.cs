﻿namespace BiblioConnect.Services;

using BiblioConnect.DbContext;
using BiblioConnect.Models.Entities;

public class PaymentService
{
    private readonly BiblioConnectDbContext _dbContext;

    public PaymentService(BiblioConnectDbContext dbContext)
    {
        _dbContext = dbContext;
    }

    public List<GetPaymentForClientResponse> GetForUser(int clientId)
    {
        List<GetPaymentForClientResponse> result = new List<GetPaymentForClientResponse>();
        var payments = _dbContext.Payments.Where(x => x.ClientID == clientId).ToList();
        foreach(var payment in payments)
        {
            var loan = _dbContext.BookLoans.First(x => x.LoanID == payment.LoanID);
            var book = _dbContext.Books.First(x => x.BookID == loan.BookID);
            result.Add(new GetPaymentForClientResponse
            {
                Title = book.Title,
                Author = book.Author,
                DueToDate = payment.DueToDate,
                Amount = payment.Amount,
                Paid = payment.Paid,
            });
        }


        return result;
    }
}