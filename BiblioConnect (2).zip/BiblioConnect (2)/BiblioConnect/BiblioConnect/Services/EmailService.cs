﻿namespace BiblioConnect.Services;

using Microsoft.EntityFrameworkCore;
using BiblioConnect.DbContext;
using Microsoft.IdentityModel.Tokens;
using BiblioConnect.Models.Entities;
using System.Data;
using System.IO;
using iText.Kernel.Pdf;
using iText.Layout;
using iText.Layout.Element;
using SendGrid.Helpers.Mail;
using SendGrid;

public class EmailService
{
    private readonly BiblioConnectDbContext _dbContext;

    public EmailService(BiblioConnectDbContext dbContext)
    {
        _dbContext = dbContext;
    }

    public async Task SendReminder3DaysEmails()
    {
        var bookLoansNearDate = await _dbContext.BookLoans
                        .Where(x => !x.Returned && EF.Functions.DateDiffDay(DateTime.Today, x.ReturnDate) == 3)
                        .ToListAsync();

        foreach (var bookLoan in bookLoansNearDate)
        {
            var client = await _dbContext.Clients.FirstOrDefaultAsync(x => x.ClientID == bookLoan.ClientID);
            var book = await _dbContext.Books.FirstOrDefaultAsync(x => x.BookID == bookLoan.BookID);
            if (client != null && !client.Email.IsNullOrEmpty() && book != null)
            {
                var body = "Dzień dobry, za 3 dni mija termin zwrotu książki " + book.Title;
                await SendEmail(client.Email, "Przypomnienie o zwrocie książki", body);
            }
        }
    }

    public async Task PrepareInvoiceEmail(BookLoan bookLoan)
    {
        try
        {
            var client = await _dbContext.Clients.FirstOrDefaultAsync(x => x.ClientID == bookLoan.ClientID);
            if (client != null && !client.Email.IsNullOrEmpty())
            {
                //decimal overdueDays = (decimal)EF.Functions.DateDiffDay(bookLoan.ReturnDate, DateTime.Today);
                //decimal invoiceAmount = overdueDays * 0.5m;
                decimal invoiceAmount = 10.0m;
                await SendInvoiceEmail(client.FirstName + " " + client.LastName, invoiceAmount, client.Email);
                Payment payment = new Payment
                {
                    ClientID = client.ClientID,
                    LoanID = bookLoan.LoanID,
                    DueToDate = DateTime.Now.AddDays(14),
                    Amount = invoiceAmount,
                    Paid = false
                };
                await _dbContext.Payments.AddAsync(payment);
                await _dbContext.SaveChangesAsync();
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Error sending emails: {ex.Message}");
        }
    }

    private async Task SendEmail(string toEmail, string subjectEmail, string body)
    {
        string apiKey = "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";
        var client = new SendGridClient(apiKey);
        var from_email = new EmailAddress("baczekk8@gmail.com", "BiblioConnect");
        var subject = subjectEmail;
        var to_email = new EmailAddress(toEmail, "Klient");
        var plainTextContent = body;
        var htmlContent = "";
        var msg = MailHelper.CreateSingleEmail(from_email, to_email, subject, plainTextContent, htmlContent);
        var response = await client.SendEmailAsync(msg).ConfigureAwait(false);
    }

    private async Task SendInvoiceEmail(string clientName, decimal invoiceAmount, string clientEmail)
    {
        var stream = new MemoryStream();
        var writer = new PdfWriter(stream);
        var pdf = new PdfDocument(writer);
        var document = new Document(pdf);
        document.Add(new Paragraph($"Dzien dobry {clientName}, niestety ksiazka nie zostala zwrocona o czasie."));
        document.Add(new Paragraph($"Kwota do zapłaty : {invoiceAmount} PLN"));
        document.Close();

        string apiKey = "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";
        var client = new SendGridClient(apiKey);
        var from_email = new EmailAddress("baczekk8@gmail.com", "BiblioConnect");
        var subject = "Faktura za przetrzymywanie książki";
        var to_email = new EmailAddress(clientEmail, clientName);
        var plainTextContent = $"Kwota do zapłaty: {invoiceAmount} PLN";
        var htmlContent = "";
        var msg = MailHelper.CreateSingleEmail(from_email, to_email, subject, plainTextContent, htmlContent);
        byte[] pdfBytes = stream.ToArray();
        msg.AddAttachment("Faktura.pdf", Convert.ToBase64String(pdfBytes), "application/pdf");
        var response = await client.SendEmailAsync(msg).ConfigureAwait(false);
    }

}