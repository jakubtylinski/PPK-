﻿namespace BiblioConnect.Services;

using BiblioConnect.DbContext;
using BiblioConnect.Models.Entities;
using EdiFabric.Templates.EdifactD96A;
using System.Data.Entity;

public class BookLoanService
{
    private readonly BiblioConnectDbContext _dbContext;
    private readonly EmailService _emailService;
    public BookLoanService(BiblioConnectDbContext dbContext, EmailService emailService)
    {
        _dbContext = dbContext;
        _emailService = emailService;
    }

    public List<GetBookLoanForClientResponse> GetForClient(int clientId)
    {
        List<GetBookLoanForClientResponse> result = new List<GetBookLoanForClientResponse>();
        var bookLoans = _dbContext.BookLoans.Where(x => x.ClientID == clientId).ToList();
        foreach (var bookLoan in bookLoans)
        {
            var book = _dbContext.Books.FirstOrDefault(x => x.BookID == bookLoan.BookID);
            if (book != null)
            {

                result.Add(new GetBookLoanForClientResponse
                {
                    LoanID = bookLoan.LoanID,
                    Title = book.Title,
                    Author = book.Author,
                    ReturnDate = bookLoan.ReturnDate,
                    LoanDate = bookLoan.LoanDate,
                    Returned = bookLoan.Returned
                });
            }
        }
        return result;
    }


    public void Insert(TSORDERS order)
    {
        var loanedBook = _dbContext.Books.FirstOrDefault(x => x.BookID == order.LINLoop.First().Id);
        BookLoan newBookLoan = new BookLoan
        {
            ClientID = order.NADLoop.First().Id,
            BookID = order.LINLoop.First().Id,
            LoanDate = DateTime.Now,
            ReturnDate = DateTime.Now.AddDays(30),
            Returned = false
        };
        if (loanedBook != null)
        {
            loanedBook.AvailableCopies--;
        }
        _dbContext.BookLoans.Add(newBookLoan);
        _dbContext.SaveChanges();
    }

    public async Task ReturnBook(TSORDERS order)
    {
        var existingLoan = _dbContext.BookLoans.FirstOrDefault(x => x.LoanID == order.APRLoop.First().Id);

        if (existingLoan != null)
        {
            existingLoan.Returned = true;
            if (DateTime.Today > existingLoan.ReturnDate)
            {
                await _emailService.PrepareInvoiceEmail(existingLoan);
            }
            var book = _dbContext.Books.First(x => x.BookID == existingLoan.BookID);
            book.AvailableCopies++;
            _dbContext.SaveChanges();
        }
    }
}